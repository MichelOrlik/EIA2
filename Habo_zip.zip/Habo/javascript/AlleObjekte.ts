namespace HabosHaihappen {
    export class AlleObjekte {
		type: string;
		x: number;
		y: number;

		constructor() {
			//;
		}

		draw(): void {
			//;
		}

    	update(): void {
			this.draw();
		}

    }
}
