/*
Aufgabe: Endabgabe
Name: Orlik, Michel
Matrikel: 261370
Datum: 28.07.2019
    
Hiermit versichere ich, dass ich diesen Code selbst geschrieben habe. Er wurde nicht kopiert und auch nicht diktiert.
*/
var HabosHaihappen;
(function (HabosHaihappen) {
    class AlleObjekte {
        constructor() {
            //;
        }
        draw() {
            //;
        }
        update() {
            this.draw();
        }
    }
    HabosHaihappen.AlleObjekte = AlleObjekte;
})(HabosHaihappen || (HabosHaihappen = {}));
//# sourceMappingURL=AlleObjekte.js.map