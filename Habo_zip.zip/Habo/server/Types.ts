interface Punktzahl {
    [key: string]: string;
}

interface Spieler {
    name: string;
    punktzahl: number;
}