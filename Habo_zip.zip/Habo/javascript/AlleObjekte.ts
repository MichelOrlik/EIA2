/*
Aufgabe: Endabgabe
Name: Orlik, Michel
Matrikel: 261370
Datum: 28.07.2019
	
Hiermit versichere ich, dass ich diesen Code selbst geschrieben habe. Er wurde nicht kopiert und auch nicht diktiert.
*/
namespace HabosHaihappen {
    export class AlleObjekte {
		type: string;
		x: number;
		y: number;

		constructor() {
			//;
		}

		draw(): void {
			//;
		}

    	update(): void {
			this.draw();
		}

    }
}
