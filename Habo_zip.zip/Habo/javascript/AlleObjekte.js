var HabosHaihappen;
(function (HabosHaihappen) {
    class AlleObjekte {
        constructor() {
            //;
        }
        draw() {
            //;
        }
        update() {
            this.draw();
        }
    }
    HabosHaihappen.AlleObjekte = AlleObjekte;
})(HabosHaihappen || (HabosHaihappen = {}));
//# sourceMappingURL=AlleObjekte.js.map